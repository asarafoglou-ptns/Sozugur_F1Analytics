library(shiny)
library(shinythemes)
library(httr)
library(purrr)
library(readr)
library(htmltools)

# ui
ui <- fluidPage(
  theme = shinytheme("united"),
  titlePanel("Formula 1 Analytics"),
  sidebarLayout(
    sidebarPanel(
      selectInput("selectYear", "Select Year", choices = c("2020", "2021", "2022", "2023")),
      selectInput("selectCircuit", "Select Circuit", choices = NULL),
      selectInput("selectDriver", "Select Driver", choices = NULL)
    ),
    mainPanel(
      uiOutput("circuitImage"), 
      uiOutput("driverMeme"),   
      textOutput("driverProfile"),
      textOutput("driverStandings")
    )
  )
)

# Server
server <- function(input, output, session) {

  observeEvent(input$selectYear, {
    res <- GET(paste0("http://ergast.com/api/f1/", input$selectYear, "/circuits.json"))
    data <- content(res, "parsed")
    circuit_ids <- sapply(data$MRData$CircuitTable$Circuits, function(x) x$circuitId)
    circuit_names <- sapply(data$MRData$CircuitTable$Circuits, function(x) x$circuitName)
    names(circuit_ids) <- circuit_names
    updateSelectInput(session, "selectCircuit", choices = circuit_ids)
  })
  
  # Display the selected circuit's URL from CSV
  output$circuitImage <- renderUI({
    req(input$selectCircuit)
    
    # Debugging: Print the selected circuit ID and corresponding row
    print(paste("Selected Circuit ID:", input$selectCircuit))
    selected_circuit <- circuits_data[circuits_data$circuitRef == input$selectCircuit, ]
    print(selected_circuit)
    
    if (nrow(selected_circuit) > 0) {
      svg_url <- as.character(selected_circuit$imageURL)
      html_widget <- tags$iframe(src = svg_url, width = "100%", height = "600px")
      browsable(html_widget)
    } else {
      tags$p("Circuit image URL not available")
    }
  })
  
  # Populate drivers using the data from CSV
  observe({
    drivers_list <- unique(drivers_memes$driverRef)
    updateSelectInput(session, "selectDriver", choices = drivers_list)
  })
  
  # Display driver profile
  output$driverProfile <- renderText({
    req(input$selectDriver)
    selected_driver <- drivers_memes[drivers_memes$driverRef == input$selectDriver, ]
    if (nrow(selected_driver) > 0) {
      paste("Name:", selected_driver$full_name,
            "\nDOB:", selected_driver$dob,
            "\nNationality:", selected_driver$nationality)
    } else {
      "Driver profile not available"
    }
  })
  
  # Display driver meme
  output$driverMeme <- renderUI({
    req(input$selectDriver)
    selected_driver <- drivers_memes[drivers_memes$driverRef == input$selectDriver, ]
    if (nrow(selected_driver) > 0) {
      meme_url <- as.character(selected_driver$memes)
      html_widget <- tags$iframe(src = meme_url, width = "90%", height = "400px")
      browsable(html_widget)
    } else {
      meme_url <- "https://www.reddit.com/media?url=https%3A%2F%2Fi.redd.it%2F9wypzo9v5zla1.jpg"
      html_widget <- tags$iframe(src = meme_url, width = "90%", height = "400px")
      browsable(html_widget)
    }
  })
}

# Run the app
shinyApp(ui = ui, server = server)
