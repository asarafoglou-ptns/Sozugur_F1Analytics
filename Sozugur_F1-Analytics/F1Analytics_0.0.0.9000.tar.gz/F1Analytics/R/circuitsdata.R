#' @title Circuits Dataset
#' @description This dataset includes the links to render the circuit images for the app
"circuits_data"